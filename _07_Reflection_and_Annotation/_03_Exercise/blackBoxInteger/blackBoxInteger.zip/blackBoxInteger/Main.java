package blackBoxInteger;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

public class Main {

    private static BlackBoxInt myObject;

    public static <myObject> void main(String[] args) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchFieldException {
        Scanner scan = new Scanner(System.in);
        Class<BlackBoxInt> reflection = BlackBoxInt.class;
        Constructor<BlackBoxInt> constructor = reflection.getDeclaredConstructor();
        constructor.setAccessible(true);
        myObject = (BlackBoxInt) constructor.newInstance();
        Field field = reflection.getDeclaredField("innerValue");
        field.setAccessible(true);

        while (true) {
            String command = scan.nextLine();
            if (command.equals("END")) {
                break;
            }
            String[] info = command.split("_");
            String instruction = info[0];
            int value = Integer.parseInt(info[1]);

            switch (instruction) {
                case "add" -> {
                    manipulateValue(reflection, "add", value, field);
                }
                case "subtract" -> {
                    manipulateValue(reflection, "subtract", value, field);
                }
                case "divide" -> {
                    manipulateValue(reflection, "divide", value, field);
                }
                case "multiply" -> {
                    manipulateValue(reflection, "multiply", value, field);
                }
                case "leftShift" -> {
                    manipulateValue(reflection, "leftShift", value, field);
                }
                case "rightShift" -> {
                    manipulateValue(reflection, "rightShift", value, field);
                }
            }
        }

    }

    private static void manipulateValue(Class<BlackBoxInt> reflection, String name, int value, Field field) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        Method method = reflection.getDeclaredMethod(name, int.class);
        method.setAccessible(true);
        method.invoke(myObject, value);
        System.out.println(field.get(myObject));
    }
}
