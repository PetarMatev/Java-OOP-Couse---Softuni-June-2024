package _06_Animals;

public class ExceptionMessages {
    public final static String INVALID_INPUT = "Invalid input!";
}
