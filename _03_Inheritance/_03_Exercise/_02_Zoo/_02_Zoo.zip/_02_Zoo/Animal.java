package _02_Zoo;

public class Animal {

    private String name;

    public Animal(String name) {
        this.name = name;
    }

    private String getName() {
        return name;
    }
}
