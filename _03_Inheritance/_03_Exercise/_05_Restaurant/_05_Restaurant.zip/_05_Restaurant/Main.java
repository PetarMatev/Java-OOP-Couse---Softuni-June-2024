package _05_Restaurant;

public class Main {
}
