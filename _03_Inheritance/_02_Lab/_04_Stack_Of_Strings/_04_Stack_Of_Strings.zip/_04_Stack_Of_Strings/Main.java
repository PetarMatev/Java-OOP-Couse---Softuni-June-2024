package _04_Stack_Of_Strings;

public class Main {
    public static void main(String[] args) {
    }
}
