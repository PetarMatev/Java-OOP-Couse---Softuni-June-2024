package Java_OOP_June_2024._01_Working_with_Abstraction._02_Exercise._04_Traffic_Lights;

public enum Color {
    RED,
    GREEN,
    YELLOW,



}
