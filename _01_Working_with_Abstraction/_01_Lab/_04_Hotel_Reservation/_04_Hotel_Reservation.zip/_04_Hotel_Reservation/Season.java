package Java_OOP_June_2024._01_Working_with_Abstraction._01_Lab._04_Hotel_Reservation;

public enum Season {
    Autumn(1),
    Spring(2),
    Winter(3),
    Summer(4);

    private final int period;

    Season(int period) {
        this.period = period;
    }

    public int getPeriod() {
        return this.period;
    }
}
