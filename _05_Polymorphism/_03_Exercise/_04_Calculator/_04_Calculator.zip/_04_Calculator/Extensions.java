package _04_Calculator;

public class Extensions {

    // util class
    private Extensions() {

    }

    public static InputInterpreter buildInterpreter(CalculationEngine engine) {
        return new ExtendedInterpreter(engine);
    }
}
