package Java_OOP_June_2024._05_Polymorphism._02_Lab._04_Wild_Farm;

public class Vegetable extends Food{
    public Vegetable(int quantity) {
        super(quantity);
    }
}
