package Java_OOP_June_2024._05_Polymorphism._02_Lab._04_Wild_Farm;

public abstract class Felime extends Mammal {

    protected Felime(String animalName, String animalType, Double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }


}
