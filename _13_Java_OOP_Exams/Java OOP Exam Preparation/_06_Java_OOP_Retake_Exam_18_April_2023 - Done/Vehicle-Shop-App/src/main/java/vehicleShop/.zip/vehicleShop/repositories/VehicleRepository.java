package vehicleShop.repositories;

import vehicleShop.models.vehicle.Vehicle;

import java.util.ArrayList;
import java.util.Collection;

public class VehicleRepository implements Repository {

    private Collection<Vehicle> vehicles;

    public VehicleRepository() {
        this.vehicles = new ArrayList<>();
    }

    @Override
    public Collection getWorkers() {
        return this.vehicles;
    }

    @Override
    public void add(Object model) {
        this.vehicles.add((Vehicle) model);
    }

    @Override
    public boolean remove(Object model) {
        String workerName = ((Vehicle) model).getName();
        return (this.vehicles.removeIf(vehicle -> vehicle.getName().equals(workerName)));
    }

    @Override
    public Object findByName(String name) {
        return (this.vehicles.stream().filter(v -> v.getName().equals(name)).findFirst().orElse(null));
    }
}
