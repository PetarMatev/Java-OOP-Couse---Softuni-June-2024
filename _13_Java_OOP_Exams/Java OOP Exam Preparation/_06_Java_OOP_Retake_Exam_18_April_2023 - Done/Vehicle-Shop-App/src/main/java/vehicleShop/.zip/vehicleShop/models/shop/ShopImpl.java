package vehicleShop.models.shop;

import vehicleShop.models.tool.Tool;
import vehicleShop.models.vehicle.Vehicle;
import vehicleShop.models.worker.Worker;

import java.util.Collection;
import java.util.Iterator;

public class ShopImpl implements Shop {
    @Override
    public void make(Vehicle vehicle, Worker worker) {
        Collection<Tool> workerCollectionOfTools = worker.getTools();
        Iterator<Tool> iterator = workerCollectionOfTools.iterator();

        while (iterator.hasNext() && worker.canWork()) {
            Tool tool = iterator.next();

            while (!tool.isUnfit() && worker.canWork() && !vehicle.reached()) {
                tool.decreasesPower();
                vehicle.making();
                worker.working();

                if (tool.isUnfit()) {
                    break;
                }
            }

            if (vehicle.reached()) {
                break;
            }
        }
    }
}
