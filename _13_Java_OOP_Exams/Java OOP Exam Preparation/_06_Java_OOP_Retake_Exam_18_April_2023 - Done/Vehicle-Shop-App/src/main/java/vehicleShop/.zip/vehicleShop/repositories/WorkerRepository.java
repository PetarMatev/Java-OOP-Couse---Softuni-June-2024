package vehicleShop.repositories;

import vehicleShop.models.worker.Worker;

import java.util.ArrayList;
import java.util.Collection;

public class WorkerRepository implements Repository {

    private Collection<Worker> workers;

    public WorkerRepository() {
        this.workers = new ArrayList<>();
    }

    @Override
    public Collection getWorkers() {
        return this.workers;
    }

    @Override
    public void add(Object model) {
        this.workers.add((Worker) model);
    }

    @Override
    public boolean remove(Object model) {
        String workerName = ((Worker) model).getName();
        return (this.workers.removeIf(worker -> worker.getName().equals(workerName)));
    }

    @Override
    public Object findByName(String name) {
        return (this.workers.stream().filter(w -> w.getName().equals(name)).findFirst().orElse(null));
    }
}
