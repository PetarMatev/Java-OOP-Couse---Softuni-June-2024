package christmasPastryShop.entities.delicacies.interfaces;

public class Stolen extends BaseDelicacy {
    protected Stolen(String name, double price) {
        super(name, 250, price);
    }
}
