package christmasPastryShop.entities.cocktails.interfaces;

public class Hibernation extends BaseCocktail {
    protected Hibernation(String name, int size, String brand) {
        super(name, size, 4.50, brand);
    }
}
