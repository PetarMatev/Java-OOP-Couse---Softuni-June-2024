package christmasPastryShop.entities.booths.interfaces;

public class PrivateBooth extends BaseBooth{
    protected PrivateBooth(int boothNumber, int capacity) {
        super(boothNumber, capacity, 3.50);
    }
}
