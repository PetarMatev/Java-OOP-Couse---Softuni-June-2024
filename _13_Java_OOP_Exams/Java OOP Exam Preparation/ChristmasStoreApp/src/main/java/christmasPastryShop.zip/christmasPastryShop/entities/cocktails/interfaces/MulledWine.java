package christmasPastryShop.entities.cocktails.interfaces;

public class MulledWine extends BaseCocktail {

    protected MulledWine(String name, int size, String brand) {
        super(name, size, 3.50, brand);
    }
}
