package furnitureFactory.entities.factories;

public class OrdinaryFactory extends BaseFactory {

    public OrdinaryFactory(String name) {
        super(name);
    }
}
