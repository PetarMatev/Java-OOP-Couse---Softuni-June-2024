package furnitureFactory.entities.wood;

public class OakWood extends BaseWood {

    public OakWood() {
        super(200);
    }
}
