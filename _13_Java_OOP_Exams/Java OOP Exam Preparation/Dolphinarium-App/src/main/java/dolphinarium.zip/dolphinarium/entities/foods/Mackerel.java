package dolphinarium.entities.foods;

public class Mackerel extends BaseFood {

    private static final int CALORIES = 305;

    public Mackerel() {
        super(CALORIES);
    }
}
