package restaurant.core;

public interface Engine extends Runnable{

}
