package harpoonDiver.common;

public class ConstantMessages {
    public static final String DIVER_ADDED = "Added %s: %s.";

    public static final String DIVER_REMOVE = "Diver %s has removed!";

    public static final String DIVING_SITE_ADDED = "Added site: %s.";

    public static final String SITE_DIVING = "The dive took place at %s. %d diver/s was/were removed on this dive.";

    public static final String FINAL_DIVING_SITES = "The dive took place at %d site/s.";

    public static final String FINAL_DIVERS_STATISTICS = "Diver's statistics:";

    public static final String FINAL_DIVER_NAME = "Name: %s";

    public static final String FINAL_DIVER_OXYGEN = "Oxygen: %.0f";

    public static final String FINAL_DIVER_CATCH = "Diver's catch: %s";

    public static final String FINAL_DIVER_CATCH_DELIMITER = ", ";
}
