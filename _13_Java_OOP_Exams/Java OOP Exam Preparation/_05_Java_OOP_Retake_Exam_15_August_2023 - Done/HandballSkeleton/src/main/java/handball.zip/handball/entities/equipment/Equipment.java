package handball.entities.equipment;

public interface Equipment {
    int getProtection();
    double getPrice();
}
