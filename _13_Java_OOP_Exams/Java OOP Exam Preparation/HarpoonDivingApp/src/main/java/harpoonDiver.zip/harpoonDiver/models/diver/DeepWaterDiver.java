package harpoonDiver.models.diver;

public class DeepWaterDiver extends BaseDiver {
    protected DeepWaterDiver(String name) {
        super(name, 90);
    }
}
