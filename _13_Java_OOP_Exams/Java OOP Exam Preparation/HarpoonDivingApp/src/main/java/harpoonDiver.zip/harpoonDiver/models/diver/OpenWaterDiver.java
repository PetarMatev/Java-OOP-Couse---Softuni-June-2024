package harpoonDiver.models.diver;

public class OpenWaterDiver extends BaseDiver {

    protected OpenWaterDiver(String name) {
        super(name, 30);
    }
}
