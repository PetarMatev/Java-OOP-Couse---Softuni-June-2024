package harpoonDiver.models.diver;

public class WreckDiver extends BaseDiver {
    protected WreckDiver(String name) {
        super(name, 150);
    }
}
