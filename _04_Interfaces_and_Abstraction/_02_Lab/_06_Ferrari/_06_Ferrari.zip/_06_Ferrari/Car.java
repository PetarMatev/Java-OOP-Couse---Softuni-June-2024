package _06_Ferrari;

public interface Car {

    String brakes();

    String gas();
}
