package _04_Say_Hello_Extended;

public interface Person {

    String getName();

    String sayHello();

}
