package _03_Say_Hello;

public interface Person {

    public String getName();

    public String sayHello();

}
