package _02_Car_Shop_Extended;

public interface Rentable {

    Integer getMinRentDay();

    Double getPricePerDay();
}
