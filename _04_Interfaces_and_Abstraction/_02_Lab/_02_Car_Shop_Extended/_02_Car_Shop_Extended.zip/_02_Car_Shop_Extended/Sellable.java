package _02_Car_Shop_Extended;

public interface Sellable {

    double getPrice();

}
