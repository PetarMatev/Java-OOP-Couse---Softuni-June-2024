package _03_Birthday_Celebrations;

public interface Identifiable {

    String getId();

}
