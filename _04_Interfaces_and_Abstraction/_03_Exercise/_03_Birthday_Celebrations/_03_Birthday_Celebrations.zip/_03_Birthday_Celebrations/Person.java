package _03_Birthday_Celebrations;

public interface Person {

    String getName();

    int getAge();

}
