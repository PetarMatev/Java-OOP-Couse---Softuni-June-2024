package _02_Multiple_Implementation;

public interface Person {

    String getName();

    int getAge();

}
