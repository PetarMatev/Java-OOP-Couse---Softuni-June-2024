package _02_Multiple_Implementation;

public interface Birthable {

    String getBirthDate();
}
